"""Mineral Watch Document Processor."""

__version__ = "0.1.0"
